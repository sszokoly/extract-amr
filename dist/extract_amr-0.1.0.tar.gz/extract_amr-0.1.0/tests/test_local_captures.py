"""Optional validation of local captures against independent TShark results."""

import hashlib
import io
from collections import Counter
from pathlib import Path

import pytest

from extract_amr import api
from extract_amr.models import Codec, FlowKey, FlowSelector, PayloadMode, SelectedFlow

PROJECT_ROOT = Path(__file__).parent.parent


LOCAL_CASES = (
    (
        "amr.pcapng",
        "42e524c9771827b1ad7b91406216bb7e4b6fe5e7b3beeb7d83c3b40e887e25c2",
        FlowKey(
            "184.150.75.230",
            "184.150.17.245",
            44486,
            36624,
            2773611115,
            98,
        ),
        Codec.AMR,
        6355,
        {7: 6061, 8: 294},
        1385,
        195722,
        "4ad57fb54e3570c7564ef72940c0c9e4c44c330b5724b468d5d5a6ceeaf04315",
    ),
    (
        "amrwb.pcapng",
        "81a7734344674582c7265cbd6016624fd97c53fb263c09bac417d1547bff7468",
        FlowKey(
            "184.150.75.230",
            "184.150.17.245",
            43882,
            36622,
            16829716,
            97,
        ),
        Codec.AMR_WB,
        3627,
        {2: 2763, 9: 864},
        5272,
        96372,
        "e73165e262604afe177b25592ba36858cb8671434bf1e3087e0ed193e23992af",
    ),
)


def _selector(key: FlowKey) -> FlowSelector:
    return FlowSelector(
        src_address=key.src_address,
        dst_address=key.dst_address,
        src_port=key.src_port,
        dst_port=key.dst_port,
        ssrc=key.ssrc,
        payload_type=key.payload_type,
    )


@pytest.mark.parametrize(
    ("name,capture_hash,flow_key,codec,frame_count,frame_types,gap_count,output_size,output_hash"),
    LOCAL_CASES,
)
def test_local_octet_aligned_capture_matches_independent_reference(
    name: str,
    capture_hash: str,
    flow_key: FlowKey,
    codec: Codec,
    frame_count: int,
    frame_types: dict,
    gap_count: int,
    output_size: int,
    output_hash: str,
) -> None:
    capture = PROJECT_ROOT / "pcaps" / name
    if not capture.is_file():
        pytest.skip(f"optional local capture is unavailable: {capture}")
    assert hashlib.sha256(capture.read_bytes()).hexdigest() == capture_hash

    selection = SelectedFlow(
        candidate_id="independent-local-reference",
        flow_key=flow_key,
        codec=codec,
        payload_mode=PayloadMode.OCTET_ALIGNED,
        first_packet_number=1,
    )
    observed_types = Counter(frame.frame_type for frame in api.iter_frames(capture, selection))
    output = io.BytesIO()
    report = api.extract_pcap(
        capture,
        output,
        selector=_selector(flow_key),
        codec=codec,
        payload_mode=PayloadMode.OCTET_ALIGNED,
    )
    output_bytes = output.getvalue()

    assert observed_types == frame_types
    assert report.capture_pass_count == 1
    assert report.capture_packet_count == frame_count
    assert report.selected_rtp_packet_count == frame_count
    assert report.emitted_frame_count == frame_count
    assert report.bad_quality_frame_count == 0
    assert report.malformed_packet_count == 0
    assert report.gap_count == gap_count
    assert len(output_bytes) == output_size
    assert hashlib.sha256(output_bytes).hexdigest() == output_hash
